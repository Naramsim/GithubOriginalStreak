![icon](https://raw.githubusercontent.com/Naramsim/GithubOriginalStreak/master/icons/g48.png) GithubOriginalStreak ![License](https://img.shields.io/badge/License-MPL2.0-yellowgreen.svg)
===

Revert GitHub contributions and streak. A browser extension.
- [x] Total Contributions
- [x] Longest Streak
- [x] Current Streak

#### Support
![chrome](https://img.shields.io/badge/extension-chrome-brightgreen.svg)
![firefox](https://img.shields.io/badge/extension-firefox-red.svg)

